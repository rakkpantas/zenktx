
(() => {
  const grid = document.getElementById('contentGrid');
  const trigger = document.getElementById('loadMoreTrigger');
  const loadingEl = document.getElementById('loading');
  const type = document.body.dataset.type;

  if(!grid || !trigger || !loadingEl) return;
  if(type !== 'movie' && type !== 'tv') return;

  // Start from however many cards are already on the page (pre-rendered by PHP)
  // so we don't get stuck at 10/20 due to offset mismatch.
  let offset = grid ? grid.children.length : 0;
  let loading = false;
  let reachedEnd = false;
  // Read current filters from URL so subsequent loads match what the user sees.
  const currentUrl = new URL(window.location.href);
  let genre = (currentUrl.searchParams.get('genre') || '').trim();
  let query = (currentUrl.searchParams.get('q') || '').trim();
  let actor = (currentUrl.searchParams.get('actor') || '').trim();
  let observer = null;

  // Fallback infinite scroll in case IntersectionObserver doesn't fire
  // (some in-app browsers / older WebViews).
  let scrollFallbackBound = false;
  function bindScrollFallback(){
    if(scrollFallbackBound) return;
    scrollFallbackBound = true;

    let ticking = false;
    const onScroll = () => {
      if(ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        if(loading || reachedEnd) return;

        // If the trigger is within ~900px of viewport bottom, load more.
        const rect = trigger.getBoundingClientRect();
        if(rect.top - window.innerHeight < 900){
          loadMore();
        }
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    // Run once to catch short pages.
    onScroll();
  }

  function setStatus(state){
    // state: 'idle' | 'loading' | 'end'
    loadingEl.style.display = 'block';
    if(state === 'loading'){
      loadingEl.innerHTML = '⏳ Loading more...';
      loadingEl.setAttribute('aria-busy', 'true');
      return;
    }
    loadingEl.setAttribute('aria-busy', 'false');
    if(state === 'end'){
      loadingEl.innerHTML = '✅ No more results';
      return;
    }
    loadingEl.innerHTML = '⬇️ Load more';
  }

  function attachFadeIn(container){
    container.classList.add('fade-in');
  }

  function initObserver(){
    if(observer) observer.disconnect();
    if(!('IntersectionObserver' in window)){
      bindScrollFallback();
      return;
    }

    observer = new IntersectionObserver(entries => {
      if(entries[0].isIntersecting && !loading && !reachedEnd){
        loadMore();
      }
    }, {
      // Load earlier so the user never "hits the bottom" waiting for posters
      rootMargin: '700px 0px',
      threshold: 0.01
    });
    observer.observe(trigger);

    // Also bind scroll fallback as a safety net (some browsers will never
    // intersect 0-height sentinels reliably).
    bindScrollFallback();
  }

  function createCard(item){
    const card = document.createElement('div');
    card.className = 'movie-card fade-in';
    card.onclick = () => window.watchMovie && window.watchMovie(item.imdb_id);

    const wrap = document.createElement('div');
    wrap.style.position = 'relative';

    const img = document.createElement('img');
    img.loading = 'lazy';
    img.src = item.poster;
    img.alt = item.title;
    img.className = 'movie-poster';

    const label = document.createElement('span');
    label.className = 'movie-label';
    label.textContent = item.label;

    const rating = document.createElement('span');
    rating.className = 'movie-rating movie-rating-overlay';
    rating.textContent = `⭐ ${item.rating}`;

    wrap.appendChild(img);
    wrap.appendChild(label);
    wrap.appendChild(rating);

    const info = document.createElement('div');
    info.className = 'movie-info';

    const titleEl = document.createElement('h3');
    titleEl.className = 'movie-title';
    titleEl.textContent = item.title;

    const yearEl = document.createElement('p');
    yearEl.className = 'movie-year';
    yearEl.textContent = item.year;

    info.appendChild(titleEl);
    info.appendChild(yearEl);

    card.appendChild(wrap);
    card.appendChild(info);
    return card;
  }

  function loadMore(){
    loading = true;
    setStatus('loading');

    const url = `load_more.php?format=json&type=${encodeURIComponent(type)}&offset=${offset}&genre=${encodeURIComponent(genre)}&q=${encodeURIComponent(query)}&actor=${encodeURIComponent(actor)}`;
    fetch(url, { headers: { 'Accept': 'application/json' } })
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(data => {
        const items = (data && Array.isArray(data.items)) ? data.items : [];
        if(items.length === 0){
          reachedEnd = true;
          if(observer) observer.disconnect();
          setStatus('end');
          return;
        }

        const frag = document.createDocumentFragment();
        for (const item of items) {
          frag.appendChild(createCard(item));
        }
        grid.appendChild(frag);

        offset += items.length;

        if(data && data.hasMore === false){
          reachedEnd = true;
          if(observer) observer.disconnect();
          setStatus('end');
          return;
        }
        setStatus('idle');
      })
      .catch(() => {
        // If the request fails, keep the indicator so the user can tap to retry.
        setStatus('idle');
      })
      .finally(() => {
        loading = false;
        if(!reachedEnd) setStatus('idle');
      });
  }

  // Tap/click "Load more" indicator as a manual fallback.
  loadingEl.style.cursor = 'pointer';
  loadingEl.addEventListener('click', () => {
    if(!loading && !reachedEnd) loadMore();
  });

  // Public API for inline handlers
  window.setGenre = function(g){
    genre = (g || '').trim();
    resetAndLoad();
  };

  window.setSearch = function(q){
    query = (q || '').trim();
    resetAndLoad();
  };

  function resetAndLoad(){
    offset = 0;
    reachedEnd = false;
    grid.innerHTML = '';
    initObserver();
    loadMore();
  }

  // show bottom indicator even before the first extra load
  setStatus('idle');
  initObserver();
})();