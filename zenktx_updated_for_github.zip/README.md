# ZenKTX Movie Platform

## Setup Instructions

1. Clone this repository:
   git clone https://github.com/YOUR_USERNAME/zenktx.git

2. Upload to your local server (XAMPP, Laragon, or any PHP server).

3. Configure API Keys:
   - Open config/omdb.php and set your OMDB API key.
   - Open config/tmdb.php and set your TMDB API key.

4. Make sure PHP is enabled on your server.

5. Access via:
   http://localhost/zenktx

## Notes
- The cache folder is auto-generated when API requests are made.
- Do not commit API keys publicly.
