<?php
return [
    'api_key' => 'YOUR_OMDB_API_KEY'
];
