<?php
return [
    'api_key' => 'YOUR_TMDB_API_KEY'
];
