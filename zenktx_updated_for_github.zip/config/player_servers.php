<?php
return [
  'server1_base' => 'https://vidsrc.me',
  'server2_base' => 'https://www.vidking.net',
  'server3_base' => 'https://player.videasy.net',
];
